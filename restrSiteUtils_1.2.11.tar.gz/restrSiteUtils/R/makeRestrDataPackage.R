
makeRestrDataPackage <-
  function( dir, recogSeq, freezeName,  genomeBSPkg,
  restEnzyme, installLib=NULL, authorName, all.chr )
{
  ## Purpose: Created RangedData instances from which distances to
  ## restriction sites can be calculated and matched random controls
  ## can be sampled
  ## ----------------------------------------------------------------------
  ## Arguments:
  ##    dir - name of package
  ##    recogSeq - FASTA sequence(s) of recognition sequence
  ##    all.chr - chromos to use in contruction package
  ##    genomeBSPkg - the BSgenome data package nam
  ##    freezeName - the freeze name to use
  ##    restEnzyme - name of enzyme or cocktail
  ##    installLib - (TRUE || <install dirname> ) else no install
  ##    authorName - how to name this data package
  ## ----------------------------------------------------------------------
  ## Author: Charles Berry, Date: 31 Dec 2009, 13:30
  ## much revised: Nov 3 13:41:01 2010

############################################################
### take it from the top:

  mc <- match.call()
  suppressPackageStartupMessages( require( genomeBSPkg, character.only=TRUE ) )
  BSPkg <- paste("package",genomeBSPkg,sep=':')
  speciesName <- ls( BSPkg )[1]  ## take first version of name
  genoDesc <- as( get( speciesName ),"GenomeDescription")
  if (missing(freezeName)) freezeName <- providerVersion(genoDesc)
  if (missing(authorName)) authorName <- "BushmanLab IT Team"
  if (missing(all.chr)) all.chr <- seqnames(genoDesc)[!isCircular(genoDesc)]
  
  width.GR <- new( "restrEnzyme",
                  makeRestrObj( recogSeq, speciesName, all.chr ),
                  genoDesc,
                  recogSeq=recogSeq,
                  reName=restEnzyme)

### and tag on some metadata so downstream apps can check on the
### validity of the object:

  metadata(width.GR) <-
      list( call = mc, enzyme=restEnzyme, bsgenomeName = genomeBSPkg,
           freeze = freezeName, rSeq=recogSeq ,chromomsomes=all.chr,
           GenomeDescription = genoDesc
           )
  suppressWarnings(
      ## we abused GRanges by extending positions beyond chromo ends
      seqinfo(width.GR) <- seqinfo(genoDesc)[all.chr,]
      )
### make a source tree:

  makeSkeleton(dir,recogSeq, freezeName, genomeBSPkg, all.chr,
               restEnzyme, authorName)


### populate the data dir:

  save(width.GR,file=file.path(dir,"data","width.GR.rda"))

  if (is.null(installLib)|| (is.logical(installLib)&&!installLib) )
      return( paste("Now run R CMD INSTALL ", dir) )

### install the source tree

  if ( length(installLib) ) installRDP( dir, installLib )

}
