### =========================================================================
### restrEnzyme objects
### -------------------------------------------------------------------------
###
### Class definition

setClass("restrEnzyme",
         representation(recogSeq="character",reName='character'),
         contains=c("GRanges","GenomeDescription"))


### - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
### Validity.
###


### - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
### Constructor.
###


### - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
### Coercion.
###

### - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
### Accessor methods.
###

setMethod("show","restrEnzyme",
          function(object){
            cat( "  restrEnzyme object\n| enzyme: ",
                 slot( object, "reName" ),
                "\n| sequence: ",
                paste(slot(object, "recogSeq"), collapse=", "),
                "\n",sep='')
            gobj <- 
              as(object,"GenomeDescription")
            show( gobj )
          }
          )
