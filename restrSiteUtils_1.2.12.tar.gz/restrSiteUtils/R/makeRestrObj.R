makeRestrObj <-
    function(recogSeq, species, all.chr ){
        ## Purpose: An object that contains restriction intervals
        ## ----------------------------------------------------------------------
        ## Arguments:
        ## | recogSeq    | FASTA sequence(s) of recognition sequence |
        ## | species     | name of species to use                    |
        ## | all.chr     | chromos to use in contructing object      |
        ## ----------------------------------------------------------------------
        ## Author: Charles Berry, Date:  2 Nov 2010, 09:15
        
        ## modified on:
        ##    Tue Jan 10 15:44:44 2012 to agree with width(sitesObject)==2
        
        ## sites in the positive orientation are recovered by restriction
        ## enzyme cuts to the right. Those in negative rientation are
        ## recovered by restriction enzyme cuts to the left.
        
        ## the result is a Granges object that has '+' ('-') intervals for
        ## the sequence ranges in which '+' ('-') oriented sites can be
        ## recovered
        
        ## this assumes that the integration site that inserts between
        ## positions i and i+1 is counted as covering 'i+0:1'
        
        ##  suppressPackageStartupMessages( require( genomeBSPkg, character.only=TRUE ) )
        position.incr <- 1L
        
        ## suppressPackageStartupMessages( require(GenomicRanges) )
        species <- get(species)
        seqlens <- seqlengths(species)
        if (missing(all.chr)) all.chr <- grep("chr[XY0-9]+$",names(seqlens),value=TRUE)
        gr <- GRanges()

        for ( xchr in all.chr ) {
            
            xchr.fasta <- species[[ xchr ]]
            
            ## get N-blocks as IRanges
            xchr.agaps <-
                as( maskMotif( as(xchr.fasta, "DNAString"), "N"), "NormalIRanges")
            
### before R-3 WAS :     as( masks( maskMotif( unmasked(xchr.fasta),"N")),
###         "NormalIRanges")
            
            ## old version - in case
            ##   xchr.agaps <-
            ##     if ("AGAPS" %in% masknames( species )){
            ##       as( masks( xchr.fasta )[[ "AGAPS" ]], "IRanges" )
            ##   } else {
            ##       new("IRanges") # No AGAPS in this genome
            ##     }
            
            xchr.length <- seqlens[ xchr ]
            tmp <- if (length(recogSeq)==1) {
                as( matchPattern(DNAString( recogSeq ), xchr.fasta , fixed="subject"),
                   "NormalIRanges")
            } else {
### combine overlapping restriction sites (as if all such are digested)
                as(do.call( c, lapply(as.list(recogSeq),
                                      function(x) as(matchPattern(DNAString( x ),
                                                                  xchr.fasta ,
                                                                  fixed="subject"
                                                                  ), "IRanges")) ),
                   "NormalIRanges")
            }
            rm(xchr.fasta)
            

            if (length(tmp)){
                ## this is a bit tricky - "+" interval can start after start of
                ## rsite or at end of gap, but can only end at start of
                ## site and only if there is no intervening gap. Need unit test.
                
                ## also by convention, the last instance of a repeat will be
                ## treated as the 'effective' restriction site.
                
                
                ## so for "+" find start of preceeding recogSite or end of
                ## preceeding gap.  And place the end on the atart of the next
                ## 'effective' restriction site.
                
                ## for "-" find end of next recogsite or start of next gap.
                ## and start from start of left recogSite.
                
                ## '+' interval start positions:
                GL <- unique( end(tmp)-width(tmp) + 1L  )
                ## usually == start()
                ## potential end positions
                GR.IR <-                    
                    IRanges(end = unique(c(1L-position.incr, end(tmp), end(xchr.agaps))), width=1)
                ## find actual ends
                after.which <- follow( IRanges(start=GL,width=1), GR.IR )
                stopifnot( all(!is.na( after.which )))
                is.gap.L <- end( GR.IR[ after.which ] ) %in% c(1L-position.incr, end( xchr.agaps ))
                recover.width.L <-  GL - start(GR.IR[ after.which ] ) +
                    ifelse( is.gap.L, 0L, width(tmp)-1L )
                ##
                ## '-' interval end positions, etc :
                GR <- unique( start(tmp)+width(tmp)-1L) ## usually end(tmp)
                GL.IR <- IRanges(start=unique( c( start( xchr.agaps ), start( tmp ) ,xchr.length+position.incr) ) , width=1)
                before.which <- precede( IRanges( end=GR, width=1 ), GL.IR )
                stopifnot(all(!is.na( before.which )))
                is.gap.R <- start( GL.IR[ before.which ] )%in% c( xchr.length+position.incr  , start( xchr.agaps ) )
                recover.width.R <-  end(GL.IR[ before.which ] )  - GR +
                    ifelse( is.gap.R, 1L, width(tmp)  )
                ##
                ## c() intervals for this chromosome to the rest
                
                gr.plus <- GRanges( seqnames=xchr, IRanges(end=GL, width=recover.width.L+1L), strand='+')
                                        #,seqlengths=xchr.length+1)
                gr.minus <-  GRanges( seqnames=xchr, IRanges(start= GR, width=recover.width.R), strand='-')
                                        #,seqlengths=xchr.length+1)
                
                gr <- suppressWarnings(
                    c(gr,  gr.plus[ order(width(gr.plus)) , ], gr.minus[ order(width(gr.minus)) , ])
                )
            } else {
                seqinfo(gr) <- seqinfo(gr)[c(seqnames(seqinfo(gr)),xchr),]
            }
        }
        rm(species)
        gr
    }
