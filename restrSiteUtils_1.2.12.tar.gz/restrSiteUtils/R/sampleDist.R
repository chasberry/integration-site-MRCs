sampleDist <-
  function(n, reDist, width.gr,parentNames=NULL,wd.tab=NULL ){

###########################################################
    ## n is number of samples per distance
    ## reDist is a vector of distances presumably between actual
    ## integration sites and the nearest restriction site in the
    ## relevant direction
###########################################################
    ## width.gr is a GRanges object with intervals between restriction
    ## sites for +/- stranded sites.The ranges have been sorted in
    ## increasing order of width on each chromosome or all hell will
    ## break loose, the strands in order '+' first, then '-', and
    ## lastly the chromosomes
###########################################################
    ## return a GRanges object that has in silico sites that are
    ## matched according to the distance to the relevant restriction
    ## site
###########################################################
   
###########################################################
    ## table all candidate ranges according to width (slowest),
    ## strand, and chromo
###########################################################
     width.tab <- table(
                       as(seqnames(width.gr),"factor"),
                       as(strand(width.gr),"factor"),
                       width(width.gr)-1)
 
    if (length(n)==1) n <- rep(n,length(reDist))
    if (is.null(parentNames)) parentNames <- as.character( 1:length(reDist) )
    stopifnot( length(parentNames)==length(reDist) )


#######################################################
### possibly there are NAs due to RE sites in unsequenced areas for
### these no result is returned. A better solution would be to find
### the distance to the gap and add some amount to that as a working
### distance to enable sampling.
#######################################################

    dist.NA <- is.na(reDist)
    parentNames <- parentNames[ !dist.NA ]
    reDist <- reDist[ !dist.NA ]
    n <- n[ !dist.NA ]
    if (any(dist.NA)) warning(paste( sum(dist.NA),"sites have NA distances"))



########################################

    
    N <- as.numeric(dimnames(width.tab)[[3]])   # widths
    total <- sum(width.tab)                     # available intervals
    ## number of intervals of this N-width or less
    width.only.N <- cumsum(unname(colSums(width.tab,dims=2L)))

    ## what or the N indexes of reDist?
    whichN <- cut(reDist, c(0, N), labels=FALSE, include.lowest=TRUE )
    ## how many intervals are NOT eligible (too short) for sampling?
    min.val <- rep(0L, length( whichN ) )
    min.val[ whichN > 1 ] <- width.only.N[ whichN[whichN>1] ]
    ## sample in the available intervals
    sampleSD <- ceiling( runif( sum(n), rep(min.val,n), total))

    ## look up cell in which each sample lies
    good.strands <- c('+','-') ## this enforces the ordering of strands in width.gr
    dmtb <- dim(width.tab)
    dmtb[2] <- 2 # ditch '*'
    cusum.tab.width.slowest <- cumsum(width.tab[, good.strands, ] )
    ## findInterval wants break_i <= x < break_j, 
    ##   but break_i < x <= break_j is required:
    cell.index <- 1+findInterval( sampleSD - 0.5, cusum.tab.width.slowest )
    cell.mat.index <- arrayInd(cell.index, dmtb )
    
    ## of the intervals at this width, which one was sampled?
    last.val <- cusum.tab.width.slowest[cell.index]
    prev.last.val <- c(0,cusum.tab.width.slowest)[ cell.index ]
    incr.SD <- sampleSD - prev.last.val

    ## now look that interval up in width.gr.
    ## construct a lookup table for groupings in width.gr
    cusum.tab.width.fastest <- cumsum(aperm(width.tab[, good.strands, ],c(3,2,1)))
    prev.fastest <- array( c( 0, head( cusum.tab.width.fastest, -1 ) ), dmtb[c(3,2,1)] )
    ## now the row number of width.gr:
    wgrIndex <- incr.SD+prev.fastest[ cell.mat.index[ ,c(3,2,1), drop=FALSE ]]  
    sampleGR <- width.gr[wgrIndex,]

    ## assign the actual position:
    pos.GR <- ifelse( as(strand(sampleGR)=='+',"vector") , end(sampleGR)-rep(reDist,n)-1L, start(sampleGR)+rep(reDist,n))
    ranges(sampleGR) <- IRanges(start=pos.GR,width=2)

    ## comment out the next two lines before releasing the package
    sdist <- distRL(sampleGR,width.gr)
    stopifnot(all(sdist==rep(reDist,n)))

    
    ## add sequence parent
    values(sampleGR)[[ "parentNames" ]] <- rep(parentNames,n)
    as(sampleGR,"GRanges")

  }


