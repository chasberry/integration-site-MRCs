distRL <- function(sites.gr,width.gr)
{
  ## Purpose: distance to nearest restriction site
  ## ----------------------------------------------------------------------
  ## Arguments:
  ##	sites.gr - GenomicRanges of genomic positions
  ##	width.gr  - GenomicRanges of restriction intervals
  ## ----------------------------------------------------------------------
  ## Author: Charles Berry, Date:  1 Jan 2010, 14:52
  ## modified on:
  ##    Wed Nov  3 13:46:33 2010 to use GRanges objects
  ##    Tue Jan 10 14:47:51 2012 for width 2 sites.gr


  stopifnot(all(width(sites.gr)==2))
  
  ## need to invoke findOverlaps( ..., type="within") and then clean
  ## up the result:

  sites.over <- suppressWarnings(
                                 findOverlaps(sites.gr,width.gr,type="within")
  )
  sites.query <- queryHits(sites.over)
  if (any(duplicated(sites.query))) stop("bad width.gr")
  sites.RE <-subjectHits(sites.over)[ match(1:length(sites.gr), sites.query) ]
  

  sites.dist <-
    (end(width.gr)[sites.RE]-end(sites.gr))*
      (strand(sites.gr) == "+") +
        (start(sites.gr)-start(width.gr)[sites.RE])*
         (strand(sites.gr) == "-") 

### old:    
### old:    abs(
### old:        start(sites.gr) -
### old:        (strand(sites.gr) == "-") * (start(width.gr)[sites.RE]) -
### old:        (strand(sites.gr) == "+") * (end(width.gr)[sites.RE])
### old:        ) 
  as(sites.dist,"vector")
}
