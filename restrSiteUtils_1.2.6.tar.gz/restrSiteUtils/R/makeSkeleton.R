makeSkeleton <- function(dir,recogSeq, freezeName, genomeBSPkg,
                         all.chr, restEnzyme, authorName)
{
  ## Purpose: Data Package Skeleton
  ## ----------------------------------------------------------------------
  ## Arguments:
  ##    dir - name of package
  ##    recogSeq - FASTA sequence(s) of recognition sequence
  ##    freezeName - the freeze name to use
  ##    genomeBSPkg - the BSgenome data package nam
  ##    all.chr - chromos to use in contruction package
  ##    restEnzyme - name of enzyme,
  ##    authorname - name
  ## ----------------------------------------------------------------------
  ## Author: Charles Berry, Date: 31 Dec 2009, 14:29
  ## modified on:
  ##    Mon Jan 16 14:04:30 2012
  
  safe.dir.create <- function(path) {
    dirTest <- function(x) !is.na(isdir <- file.info(x)$isdir) &
    isdir
    if (!dirTest(path) && !dir.create(path))
      stop(gettextf("cannot create directory '%s'", path),
           domain = NA)
  }
  
  if (missing(authorName)) authorName <- "BushmanLab IT Team"
  safe.dir.create(dir)
#  safe.dir.create(code_dir <- file.path(dir, "R"))
  safe.dir.create(docs_dir <- file.path(dir, "man"))
  safe.dir.create(data_dir <- file.path(dir, "data"))
  message("Creating DESCRIPTION ...")
  description <- file(file.path(dir, "DESCRIPTION"), "wt")

  ## in case restriction enzyme has a name with special characters,
  ## etc.

  ## TODO: make the package name here:
  
  package.name <- paste(
                        sub("BSgenome","restrEnz",genomeBSPkg),
                        "RENZ",
                        gsub("[^[:alnum:].]",".",restEnzyme),
                        sep=".")


    ## make.names(basename(dir))

  write.dcf(data.frame(Package= package.name,
                       Type="Package",
                       Title= "Restriction Site Data Objects",
                       Description="Provides Data Objects to analyze/control Restriction Bias.",
                       "Restriction Enzyme" = restEnzyme,
                       "Genome Freeze"= freezeName,
                       "Chromosomes Used"= paste(all.chr,collapse=' '),
                       Version= "1.0",
                       Date= format(Sys.time(), format = "%Y-%m-%d"),
                       Author= authorName,
                       Maintainer= "Charles C. Berry <ccberry@ucsd.edu>",
                       License="Artistic-2.0", LazyData="yes",
                       Depends="methods, GenomicRanges, restrSiteUtils",
                       check.names=FALSE),
            file = description)
  
  close(description)
  helppage <-
      file(file.path(docs_dir,
                     paste( freezeName, "-", restEnzyme,"-package.Rd",sep='')), "wt")

  cat( "\\name{",package.name,"-package}\n",
      "\\alias{",package.name,"-package}\n",
      "\\alias{",package.name,"}\n",
      "\\docType{package}\n",
      "\\title{Restriction Data Objects for\n",
      paste("\t",c("Restriction Enzyme", "freeze"),": ",
            restEnzyme, freezeName,"\n",sep=''),"}\n",
      "\\description{A GenomicRanges Object is provided}\n",
      "\\details{\n",
      "\\tabular{ll}{\n",
      "Package: \\tab ", package.name,"\\cr\n",
      "Type: \\tab Package\\cr\n",
      "Version: \\tab 1.0\\cr\n",
      "Date: ", format(Sys.time(), format = "%Y-%m-%d"),"\\cr\n",
      "License: Artistic-2.0 \\cr\n",
      "LazyLoad: \\tab yes\\cr\n",
      "}\n",
      "}\n",
      "\\note{ This package was constructed from data in the\n",
      genomeBSPkg, " package}\n",
      "\\author{", authorName,"\n",
      "Maintainer: Charles C. Berry <ccberry@ucsd.edu>\n",
      "}\n",
      file=helppage, sep="")
  close(helppage)
  
  helppage <-
      file(file.path(docs_dir,
                     paste( freezeName, "-", restEnzyme,"-objects.Rd",sep='')), "wt")

  cat( "\\name{",package.name,"-objects}\n",
      "\\alias{width.GR}\n",
      "\\docType{data}\n",
      "\\title{\n",
      "Restriction Data Object for\n",
      paste("\t",c("Restriction Enzyme", "freeze"),": ", c(restEnzyme, freezeName),"\n",sep=''),"}\n",
      "\\description{\n",
      "This object defines the ranges between restriction sites ",
      "}\n",
      "\\usage{width.GR}\n",
      "\\format{A GenomicRanges Object}\n",
      "\\note{ This package was constructed from data in the\n",
            genomeBSPkg, " package using the makeRestrDataPackage function",
      "\n using the following sequence(s) to determine the recognition sites: ",
      paste(recogSeq,collapse=' '),
      "}\n",
           "\\author{", authorName,"}\n",
      "\\section{Maintainer}{ Charles C. Berry <ccberry@ucsd.edu>}\n",
      file=helppage,sep='')
  close(helppage)

  namespace <-
    file(file.path(dir, "NAMESPACE"), "wt")
  cat("import( restrSiteUtils )\n",
      file=namespace,sep='')
  close(namespace)
  
  
  if (FALSE){ #deprecated 
    zzz <- file(file.path(code_dir, "zzz.R"), "wt")
    cat( "### as per datasets/zzz.R\n",
        "\n.noGenerics <- TRUE\n",
        " .First.lib <- function(...) {\n",
        "    lockEnvironment(as.environment(\"package:", package.name, "\"), TRUE)\n",
        "  }\n",
        file = zzz, sep='')
    close(zzz)
  }
  
  
}
