### miscellaneous checks

library( restrSiteUtils )

### build a width.GR type object, use it to calc lengths, then sample
### MRCs, then check the lengths of the sampled MRCs that resulted

foo.sites <- GRanges(seqnames=rep(c("chrA","chrB"),each=100),
                 IRanges(start=rep(101:150,4),width=2),
                 strand=rep(rep(c("+","-"), each=50),2))

foo.widths <- GRanges(seqnames=rep(c("chrA","chrB"),each=6),
                      IRanges(start=rep(c(1,102,151),4),end=rep(c(100,149,249),4)),
                      strand=rep( rep(c("+","-"), 6)))

### need to check that makeRestrObj honors this:

foo.widths <- foo.widths[order(as.vector( seqnames(foo.widths)) ,as.vector( strand(foo.widths)) , width(foo.widths)) ,]



foo2.sites <- GRanges(seqnames=c("chrA","fooey"),rep(IRanges(start=50,width=2),2),strand=rep("+",2))


### distRL checks:

foo.dist <- distRL( foo.sites, foo.widths )
foo2.dist <- distRL( foo2.sites, foo.widths )

## 4 unmatched
stopifnot(
          sum(is.na( foo.dist ) ) == 12
          )

## 1 unmatched
stopifnot(
          sum( is.na( foo2.dist ) )==1
          )

# 4 each from 0 to 46
stopifnot(
          all(sort(foo.dist)==rep(0:46,each=4))
          )

## sampleDist check

set.seed(12345)

foo.sample <- sampleDist(10L,foo.dist,foo.widths)

all( distRL(foo.sample,foo.widths)==foo.dist[as.numeric(values(foo.sample)[,"parentNames"])])

foo.sample

## makeRestrObj check

require( BSgenome.Scerevisiae.UCSC.sacCer3 )
NheI <- "GCTAGC"
obj <- restrSiteUtils:::makeRestrObj(NheI, "Scerevisiae" , c("chrI","chrII" ))

### downstream uses require this ordering:

all( 1 == diff(order(
       as.vector(seqnames(obj)),
       as.vector(strand(obj)=='-'),
       width(obj))
       )
    )

### might as well show( )  out the result

obj

### class defs

### don't mess with restrEnzyme class unless you know what you are
### doing!!!

slotNames(new("restrEnzyme"))

### currently there is no built in test that makeRestrDataPackage(),
### installRDP(), makeSkeleton() work as intended. Hopefully these
### would fail dramatically in use if they were broken, but all of the
### above tests passed.


