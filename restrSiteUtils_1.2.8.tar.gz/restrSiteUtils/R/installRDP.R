installRDP <- function(srcdir, installdir)
{
  ## Purpose: install a RestrDataPackage from source
  ## ----------------------------------------------------------------------
  ## Arguments:
  ## srcdir - path to source directory
  ## installdir - path to (optional) installdir
  ## ----------------------------------------------------------------------
  ## Author: Charles Berry, Date:  1 Jan 2010, 13:50

  package.name <- 
    read.dcf( file.path( srcdir, "DESCRIPTION") )[,'Package']
  installdir <- if (isTRUE(installdir)) .libPaths()[1L] else installdir
  stopifnot(file.exists(installdir))
  cat("\ninstalling ",srcdir,"\n as ", package.name, "\n in ", installdir,'\n',sep='')
  install.packages( pkgs=srcdir, lib=installdir, repos= NULL, type="source" )
  
}
